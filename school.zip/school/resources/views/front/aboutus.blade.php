@extends('welcome')
@section('header1')
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
@endsection

@section('content')
<div id="about" class="container-fluid carodiv">
    <div class="col-sm-8">
     <h1 class="specialh">Chantos E-School</h1>
      <h3>We provide international level of Eduication.</h3>
      <p>Chantos E-school was founded to bridge the gap of international job market and the local job market. Our objective
      is to produce employees that are well versed and equiped to work any location on the globe.
      </p><p>
      This objective is attained through learning foreig languages, study globay accepted cources, travel and experience the
      world wide expossure through e- learning- teaching from qualified teachers across the globe
      </p>
    </div>
    <div class="col-sm-4 ">
    <div class="card">
      <img src="{{asset('img/images/foto1.jpg')}}" class="img-responsive imgstyle" alt="privine" />
      <div class="container">
        <h2>Myrachanto</h2>
        <p class="title">CEO &amp; Founder</p>
        <p>Graduated with second class honours</p>
        <p>info@chantosweb.com</p>
        <p><button class="button">+254729308456</button></p>
      </div></div>
    </div>
  
</div>
@endsection