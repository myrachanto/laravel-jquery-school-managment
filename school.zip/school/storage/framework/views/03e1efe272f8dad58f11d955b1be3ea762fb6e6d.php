<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-12">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Studentwise : <?php echo e($exam->name); ?> results</h2>
     </div> 
        <div class="panel-body"> 
        <form action="<?php echo e(url('/admin/exam/Infor')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="panel-body"> <table class="table table-bordered">
      <thead>
        <tr>
          <th>First name</th>
          <th><?php echo e($student->fname); ?></th>
          <th>Last Name</th>
          <th><?php echo e($student->lname); ?></th>
        </tr>
        <tr>
          <th>Registration Number</th>
          <th><?php echo e($student->regno); ?></th>
          <th>User name</th>
          <th><?php echo e($student->username); ?></th>
        </tr>
        <tr>
          <th>English</th>
          <td><input type="text"  id="English" name="English"></td>
        </tr><tr>
          <th>Mathematics</th>
          <td><input type="text"  id="maths" name="maths"></td>
        </tr><tr>
          <th>Kiswahili</th>
          <td><input type="text"  id="Kiswahili" name="Kiswahili"></td>
        </tr><tr>
          <th>Biology</th>
          <td><input type="text"  id="Biology" name="Biology"></td>
        </tr><tr>
          <th>Geography</th>
          <td><input type="text"  id="Geography" name="Geography"></td>
        </tr><tr>
          <th>Chemistry</th>
          <td><input type="text"  id="Chemistry" name="Chemistry"></td>
        </tr><tr>
          <th>Physics</th>
          <td><input type="text"  id="Physics" name="Physics"></td>
        </tr><tr>
          <th>CRE</th>
          <td><input type="text"  id="CRE" name="CRE"></td>
        </tr><tr>
          <th>History</th>
          <td><input type="text"  id="History" name="History"></td>
        </tr><tr>
          <th>business</th>
          <td><input type="text"  id="business" name="business"></td>
        </tr><tr>
          <th>Agriculture</th>
          <td><input type="text"  id="Agriculture" name="Agriculture"></td>
        </tr><tr>
      </thead>
      <tbody>
        <tr>
          <td colspan="4">
               <input type="hidden" id="name" name="studentid" value="<?php echo e($student->id); ?>">
               <input type="hidden" id="name" name="classid" value="<?php echo e($classid); ?>">
               <input type="hidden" id="name" name="examid" value="<?php echo e($exam->id); ?>">
              <button type="submit" class="btn btn-default">submit</button></td>
          
        </tr>
      </tbody>
    </table>
            </form>
    <!-- add code ends -->
 
             </div> </div> </div> </div> </div>
</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>