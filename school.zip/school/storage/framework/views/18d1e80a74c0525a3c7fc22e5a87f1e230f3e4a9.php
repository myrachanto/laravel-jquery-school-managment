<?php $__env->startSection('content'); ?>
   <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3"><img src="<?php echo e(asset('img/imag3.jpg')); ?>" width="60" height="60" alt="myrachanto"/>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">26</div>
                                    <div>View extra curriculum activity</div>
                                </div>
                            </div>
                        </div>
                        <?php foreach($teacher as $z): ?>
                        <a href="<?php echo e(url('/admin/teacher/extracurriculum')); ?>/<?php echo e($z ->id); ?>">
                            <div class="panel-footer">
                                <span class="pull-left"><?php echo e($z -> username); ?></span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                      <?php endforeach; ?>
                    </div>
                </div>  <div class="col-lg-6 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3"><img src="<?php echo e(asset('img/imag3.jpg')); ?>" width="60" height="60" alt="myrachanto"/>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">26</div>
                                    <div>View Progress report</div>
                                </div>
                            </div>
                        </div>
                        <?php foreach($teacher as $z): ?>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left"><?php echo e($z -> username); ?></span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                      <?php endforeach; ?>
                    </div>
                </div> </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>