<?php $__env->startSection('content'); ?>

<div id="about" class="container-fluid carodiv2">
                            <div class="row">
             
                             <div class="col-lg-12">
      <div class="panel panel-default">
     <div class="panel-heading">
					  <h4>Studentfees pannel</h4>
    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
      </div>
    <?php endif; ?>
        <div class="panel-body"> <table class="table table-bordered">
      <thead>
      
        <tr>
          <th>UserName</th>
          <th><?php echo e($student->username); ?></th>
          <th></th>
          <th>Regno</th>
          <th><?php echo e($student->regno); ?></th></tr>
          <tr>
          <th>First Name</th>
          <th><?php echo e($student->fname); ?></th>
          <th></th>
          <th>Last Name</th>
          <th><?php echo e($student->lname); ?></th>
        </tr><tr>
          <th>Year of study</th>
          <th><?php echo e($student->yos); ?></th>
          <th></th>
          <th></th>
        </tr>
        <tr>
          <th>Invoice Number</th>
          <th>payments</th>
          <th>amount</th>
          <th>Payment</th>
          <th>Balance</th>
        </tr>
      </thead>
      <tbody>

    <?php foreach($finance as $x): ?>
        <tr>
          <td><a href="<?php echo e(url('/member/invoice')); ?>/<?php echo e($x -> invoiceno); ?>"><?php echo e($x -> invoiceno); ?></a></td>
          <td><?php echo e($x -> name); ?></td>
          <td><?php echo e($x -> amount); ?></td>
          <td><?php echo e($x -> payment); ?></td>
          <td></td>
        </tr>
       <?php endforeach; ?>
       
      </tbody>
    </table></div></div></div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>