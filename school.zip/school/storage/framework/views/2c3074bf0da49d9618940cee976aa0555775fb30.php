<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-12">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Promote Year <?php echo e($yos); ?> To the Next level</h2>
     </div> 
        <div class="panel-body"> 
        <form action="#" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <table class="table table-bordered">
      <thead>
        <tr>
          <th>Name</th>
          <th>Regno</th>
          <th>Acedemic year</th>
          <th>Year of study</th>
        </tr>
      </thead>
      <tbody>

    <?php foreach($promote as $x): ?>
        <tr>
          <td><?php echo e($x -> username); ?></td>
          <td><?php echo e($x -> regno); ?></td>
          <td><?php echo e($x -> academicyear); ?></td>
          <td><?php echo e($x -> yos); ?></td>
          
        </tr>
       <?php endforeach; ?>
      </tbody>
      <tr><td colspan="4" align="right">
              <button type="submit" class="btn btn-default">Print</button></td></tr>
    </table>               
            </form>
    <!-- add code ends -->
 
             </div> </div> </div> </div> </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>