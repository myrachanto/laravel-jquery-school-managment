<?php $__env->startSection('content'); ?>
   <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3"><img src="<?php echo e(asset('img/repor.jpg')); ?>" width="60" height="60" alt="myrachanto"/>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo e($classes->count()); ?></div>
                                    <div>View Information</div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(url('/admin/exam/result')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">View class performance</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                            <a href="<?php echo e(url('/admin/extra')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Extra-curriculum activities</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                            <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">class library</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                            <a href="<?php echo e(url('/admin/yos/promotion1')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Promote a class</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a></a>
                            <a href="<?php echo e(url('/admin/yos/expulsionlsit')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Expulsion list</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a></a>
                            <a href="<?php echo e(url('/admin/yos/checkclass')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">View classes</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                    </div>
                </div>
                  <div class="col-lg-6 col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3"><img src="<?php echo e(asset('img/repor.jpg')); ?>" width="60" height="60" alt="transaction"/>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo e($classes->count()); ?></div>
                                    <div>Set ups</div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(url('/admin/library')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Add a new book</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a><a href="<?php echo e(url('/admin/classes')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">add new classes</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                            <a href="<?php echo e(url('/admin/yearclass')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">add new Year classes</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                            <a href="<?php echo e(url('/admin/curriculum')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Add new extra-curriculum activity</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a></a>
                            <a href="<?php echo e(url('/admin/yos')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Add new Year of study</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                    </div>
                </div> </div>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>