<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-4">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Select a class to Promote</h2></div> 
        <div class="panel-body">
 <form action="<?php echo e(url('/admin/yos/promotion2')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group">
                   <label for="acedemicyear">Class:</label>
                        <select class="form-control" id="yos" name="yos">
                        <?php foreach($yos as $x): ?>
                        <option value="<?php echo e($x -> name); ?>"><?php echo e($x -> name); ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
              <button type="submit" class="btn btn-default">Get the form</button>
            </form>

             </div> </div> </div> 
                              <div class="col-lg-4">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Graduate</h2></div> 
        <div class="panel-body">
 <form action="<?php echo e(url('/admin/yos/promotion4')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group">
                   <label for="acedemicyear">Class:</label>
                        <select class="form-control" id="yos" name="yos">
                        <option value="four">Form four</option>
                        </select>
                    </div>
              <button type="submit" class="btn btn-default">Get the form</button>
            </form>

             </div> </div> </div> 
                                <div class="col-lg-4">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Take action to a student</h2></div> 
        <div class="panel-body">
 <form action="<?php echo e(url('/admin/exam/promotion3')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group">
                   <label for="acedemicyear">Student:</label>
                        <select class="form-control" id="student" name="student">
                        <?php foreach($student as $x): ?>
                        <option value="<?php echo e($x -> username); ?>"><?php echo e($x -> username); ?>, Regno:<?php echo e($x -> username); ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
              <button type="submit" class="btn btn-default">Take action</button>
            </form>

             </div> </div> </div> 
             
             </div> </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>