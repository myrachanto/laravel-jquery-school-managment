<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-8">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Create a new invoice-school fee</h2></div> 
        <div class="panel-body">
 <form action="<?php echo e(url('/admin/messages/messager2')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group">
                   <label for="receiverid">Receipient:</label>
                        <select class="form-control" id="yos" name="yos">
                        <?php foreach($yos as $y): ?>
                        <option value="<?php echo e($y -> name); ?>">Year <?php echo e($y -> name); ?> study Parents/Students</option>
                        <?php endforeach; ?>
                        </select>
                    </div> 
            <div class="form-group">
                  <label for="name"> title:</label>
                  <input type="text" class="form-control" id="title" name="title">
                </div>  
              <div class="form-group">
                     <div class="form-group">
                  <label for="description">Message:</label>
                <textarea class="form-control" rows="5" id="message" name="message"></textarea>
                </div>
              <button type="submit" class="btn btn-default">select the list</button>
            </form>

             </div> </div> </div> 
                                           
             </div> </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>