<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
                              
<div id="about" class="container-fluid carodiv2">
                            <div class="row"><div class="col-lg-12">
      <div class="panel panel-default">
 <form action="<?php echo e(url('/admin/yos/Afire')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
     <div class="panel-heading"><h2><?php echo e($member->username); ?> Profile</h2>  </div> 
  <div class="panel-body">
        <form action="#" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <table class="table table-bordered">
      <tbody>
        <tr>
          <td>First name</td>
          <td><?php echo e($member->fname); ?></td>
          <td>Last name</td>
          <td><?php echo e($member->lname); ?></td>
          <td colspan="3" rowspan="4"><img src="<?php echo e(asset($member->foto)); ?>" class="imgstyle" width="150" alt="<?php echo e($member->username); ?>" /></td>
        </tr>
       <tr>
           <td >Spouse Name</td>
          <td><?php echo e($member->spousename); ?></td>
           <td >Next of kin</td>
          <td><?php echo e($member->nextofkinname); ?></td>
          
        </tr><tr>
           <td >Phone number</td>
          <td><?php echo e($member->primary_p_no); ?>/<?php echo e($member->secondary_p_no); ?></td>
           <td >Extra curriculum activities</td>
          <td><?php echo e($member->extra_curruclum); ?></td>
          
        </tr>
       <tr>
           <td >email</td>
          <td><?php echo e($member->email); ?></td>
           <td >Subjects</td>
          <td><?php echo e($member->subject1); ?> and <?php echo e($member->subject2); ?></td>
          
        </tr><tr>
           <td colspan="2"><input type="hidden" id="name" value="<?php echo e($member -> id); ?>" name="teacherid">
              <button type="submit" class="btn btn-default">Fire the Accountant</button>
            </form></td>
          <td colspan="2"><form action="<?php echo e(url('/admin/yos/Ahire')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" id="name" value="<?php echo e($member -> id); ?>" name="teacherid">
              <button type="submit" class="btn btn-default">Rehire the Accountant</button>
            </form></td>
          
        </tr>
      </tbody>
    </table>
            
            
 
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>