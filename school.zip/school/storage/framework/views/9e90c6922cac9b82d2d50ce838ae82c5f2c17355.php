<?php $__env->startSection('content'); ?>

<div id="about" class="container-fluid carodiv2">
                            <div class="row">
             
                             <div class="col-lg-12">
      <div class="panel panel-default">
     <div class="panel-heading">
					  <h4>Time table day wise</h4>
    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
      </div>
    <?php endif; ?>
        <div class="panel-body"> <table class="table table-bordered">
      <thead>
        <tr>
          <th>Day</th>
          <th>class</th>
          <th> Morning Preps</th>
          <th>8:10-8:55</th>
          <th>8:55-9:30</th>
          <th> Break</th>
          <th>9:40-10:35</th>
          <th>10:30-11:00</th>
          <th> Break</th>
          <th>11:20-12:05</th>
          <th>12:05-12:50</th>
          <th> Lunch</th>
          <th>02:00-02:45</th>
          <th>02:45-03:30</th>
          <th>03:30-04:15</th>
          <th> Games</th>
          <th> Evening preps</th>
        </tr>
      </thead>
      <tbody>

    <?php foreach($teacherclass as $x): ?>
        <tr>
          <td><?php echo e($x -> day); ?></td>
          <td><?php echo e($x -> class); ?></td>
          <th> Morning Preps</th>
          <td><?php echo e($x -> first); ?></td>
          <td><?php echo e($x -> second); ?></td>
          <th> Break</th>
          <td><?php echo e($x -> third); ?></td>
          <td><?php echo e($x -> forth); ?></td>
          <th> Break</th>
          <td><?php echo e($x -> firth); ?></td>
          <td><?php echo e($x -> sixth); ?></td>
          <th> Lunch</th>
          <td><?php echo e($x -> seventh); ?></td>
          <td><?php echo e($x -> eighth); ?></td>
          <td><?php echo e($x -> nineth); ?></td>
          <th> Games</th>
          <th> Evening preps</th>
        </tr>
       <?php endforeach; ?>
      </tbody>
    </table>
    </div></div></div></div>
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>