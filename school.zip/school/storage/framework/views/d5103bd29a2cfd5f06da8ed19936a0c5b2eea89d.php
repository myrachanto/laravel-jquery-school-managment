<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Chantos eschool" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="panel-body"> <table class="table table-bordered">
      <thead>
        <tr>
      <th>#</th>
          <th>UserNames</th>
          <th>Regno</th>
    <?php foreach($subject as $s): ?>
          <th><?php echo e($s -> name); ?></th>
       <?php endforeach; ?>
        </tr>--> 
      </thead>
      <tbody>

    <?php foreach($results as $r): ?>
        <tr>
        <td><?php echo e($s -> username); ?></td>
        <td><?php echo e($s -> regno); ?></td>
          <td><?php echo e($r ->
           <?php foreach($subject as $s): ?>

          {{$s -> name); ?>


             <?php endforeach; ?>}}
       </td>
        </tr>
     <?php endforeach; ?>
      </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>