<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-12">
      <div class="panel panel-default">
     <div class="panel-heading"><h2><?php echo e($class->name); ?> Results</h2> of <?php echo e($exam->name); ?></div> 
  <div class="panel-body"> <table class="table table-bordered">
      <thead>
        <tr>
          <th>studentid</th>
          <th>Regno</th>
          <th>username</th>
          <th>English</th>
          <th>Mathematics</th>
          <th>Kiswahili</th>
          <th>Biology</th>
          <th>Geography</th>
          <th>Chemistry</th>
          <th>Physics</th>
          <th>CRE</th>
          <th>History</th>
          <th>business</th>
          <th>Agriculture</th>
          <th>Total score</th>
        </tr>
      </thead>
      <tbody>

    <?php foreach($answers as $x): ?>
        <tr>
          <td><?php echo e($x -> studentid); ?></td>
          <td><?php echo e($x -> regno); ?></td>
          <td><?php echo e($x -> username); ?></td>
          <td><?php echo e($x -> English); ?></td>
          <td><?php echo e($x -> maths); ?></td>
          <td><?php echo e($x -> Kiswahili); ?></td>
          <td><?php echo e($x -> Biology); ?></td>
          <td><?php echo e($x -> Geography); ?></td>
          <td><?php echo e($x -> Chemistry); ?></td>
          <td><?php echo e($x -> Physics); ?></td>
          <td><?php echo e($x -> CRE); ?></td>
          <td><?php echo e($x -> History); ?></td>
          <td><?php echo e($x -> business); ?></td>
          <td><?php echo e($x -> Agriculture); ?></td>
          <td><?php echo e($x -> English + $x -> maths + $x -> Kiswahili + $x -> Biology+$x -> Geography+$x -> Chemistry+$x -> Chemistry
          +$x -> Physics+$x -> CRE+$x -> History+$x -> business+$x -> Agriculture); ?></td>
          
        </tr>
       <?php endforeach; ?>
      </tbody>
    </table>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>