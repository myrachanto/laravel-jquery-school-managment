<?php $__env->startSection('content'); ?>
                            
<div id="about" class="container-fluid carodiv2">
                            <div class="row"><div class="col-lg-8">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Find the exam results</2></div> 
        <div class="panel-body">
 <form action="<?php echo e(url('/admin/student/examresults')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
             <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
             <div class="form-group">
                   <label for="acedemicyear">Student:</label>
                        <select class="form-control" id="student" name="student">
                        <?php foreach($student as $y): ?>
                        <option value="<?php echo e($y -> id); ?>"><?php echo e($y -> username); ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                        <div class="form-group">
                   <label for="acedemicyear">Exam:</label>
                        <select class="form-control" id="exam" name="exam">
                        <?php foreach($exam as $y): ?>
                        <option value="<?php echo e($y -> id); ?>"><?php echo e($y -> name); ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
              <button type="submit" class="btn btn-default">Get the results</button>
            </form>

             </div> </div> </div> 
             
             </div> </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>