<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
                              
<div id="about" class="container-fluid carodiv2">
                            <div class="row"><div class="col-lg-8">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Results of <?php echo e($exam->name); ?></h2>  </div> 
  <div class="panel-body"> <table class="table table-bordered">
      <thead>
        <tr>
          <th>First name</th>
          <th><?php echo e($student->fname); ?></th>
          <th></th>
          <th>Last Name</th>
          <th><?php echo e($student->lname); ?></th>
        </tr>
        <tr>
          <th>Registration Number</th>
          <th><?php echo e($student->regno); ?></th>
          <th></th>
          <th>User name</th>
          <th><?php echo e($student->username); ?></th>
        </tr>
        <tr>
          <th>subject</th>
          <th>score</th>
          <th>Total score</th>
          <th>Grading</th>
          <th>Comments</th>
        </tr>
      </thead>
      <tbody>
       <tr>
          <th>English</th>
          <td><?php echo e($res->English); ?></td>
          <td>/100</td>
          <td><?php echo e($e); ?></td>
          <td></td>
        </tr><tr>
          <th>Mathematics</th>
          <td><?php echo e($res->maths); ?></td>
          <td>/100</td>
          <td><?php echo e($m); ?></td>
          <td></td>
        </tr><tr>
          <th>Kiswahili</th>
          <td><?php echo e($res->Kiswahili); ?></td>
          <td>/100</td>
          <td><?php echo e($k); ?></td>
          <td></td>
        </tr><tr>
          <th>Biology</th>
          <td><?php echo e($res->Biology); ?></td>
          <td>/100</td>
          <td><?php echo e($b); ?></td>
          <td></td>
        </tr><tr>
          <th>Geography</th>
          <td><?php echo e($res->Geography); ?></td>
          <td>/100</td>
          <td><?php echo e($g); ?></td>
          <td></td>
        </tr><tr>
          <th>Chemistry</th>
          <td><?php echo e($res->Chemistry); ?></td>
          <td>/100</td>
          <td><?php echo e($c); ?></td>
          <td></td>
        </tr><tr>
          <th>Physics</th>
          <td><?php echo e($res->Physics); ?></td>
          <td>/100</td>
          <td><?php echo e($p); ?></td>
          <td></td>
        </tr><tr>
          <th>CRE</th>
          <td><?php echo e($res->CRE); ?></td>
          <td>/100</td>
          <td><?php echo e($cre); ?></td>
          <td></td>
        </tr><tr>
          <th>History</th>
          <td><?php echo e($res->History); ?></td>
          <td>/100</td>
          <td><?php echo e($h); ?></td>
          <td></td>
        </tr><tr>
          <th>business</th>
          <td><?php echo e($res->business); ?></td>
          <td>/100</td>
          <td><?php echo e($biz); ?></td>
          <td></td>
        </tr><tr>
          <th>Agriculture</th>
          <td><?php echo e($res->Agriculture); ?></td>
          <td>/100</td>
          <td><?php echo e($a); ?></td>
          <td></td>
        </tr>
       <tr>
           <td >Total Score</td>
          <td><u><?php echo e($res -> English + $res -> maths + $res -> Kiswahili + $res -> Biology+$res -> Geography+$res -> Chemistry+$res -> Chemistry
          +$res -> Physics+$res -> CRE+$res -> History+$res -> business+$res -> Agriculture); ?></u></td>
          <td>/1100</td>
          <td></td>
          <td></td>
          
        </tr>
      </tbody>
    </table>
    
              <button type="submit" class="btn btn-default">print</button>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>