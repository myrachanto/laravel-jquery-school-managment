<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
                              
<div id="about" class="container-fluid carodiv2">
                            <div class="row"><div class="col-lg-8">
      <div class="panel panel-default">
     <div class="panel-heading"><h2><?php echo e($invoiceno); ?> for Year <?php echo e($year); ?>-<?php echo e($term); ?></h2>  </div> 
  <div class="panel-body">
        <form action="<?php echo e(url('/admin/finances/confirm')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <table class="table table-bordered">
      <thead>
        <tr>
          <th>Service</th>
          <th>Year</th>
          <th>Term</th>
          <th>Amount</th>
        </tr>
      </thead>
      <tbody>

    <?php foreach($invoicedata as $x): ?>
        <tr>
          <td><?php echo e($x -> expencename); ?></td>
          <td><?php echo e($x -> year); ?></td>
          <td><?php echo e($x -> term); ?></td>
          <td>KSH: <?php echo e($x -> amount); ?></td>
          
        </tr>
       <?php endforeach; ?>
       <tr>
           <td colspan="3">Total Amount</td>
          <td><u>KSH: <?php echo e($amt); ?>/=</u></td>
          
        </tr>
      </tbody>
    </table>
     
               <input type="hidden" id="amt" value="<?php echo e($amt); ?>" name="amt">
               <input type="hidden" id="invoiceno" value="<?php echo e($invoiceno); ?>" name="invoiceno">
               <input type="hidden" id="year" value="<?php echo e($year); ?>" name="year">
               <input type="hidden" id="term" value="<?php echo e($term); ?>" name="term">
              <button type="submit" class="btn btn-default">Deploy the invoice</button>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>