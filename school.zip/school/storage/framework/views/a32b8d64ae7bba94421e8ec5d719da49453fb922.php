<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-6">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>View exam results</h2></div> 
        <div class="panel-body">
 <form action="<?php echo e(url('/admin/exam/answers')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group">
                   <label for="Class">Class:</label>
                        <select class="form-control" id="classid" name="classid">
                        <?php foreach($classes as $x): ?>
                        <option value="<?php echo e($x -> id); ?>"><?php echo e($x -> name); ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                        <div class="form-group">
                   <label for="acedemicyear">Exam:</label>
                        <select class="form-control" id="examid" name="examid">
                        <?php foreach($exam as $y): ?>
                        <option value="<?php echo e($y -> id); ?>"><?php echo e($y -> name); ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
              <button type="submit" class="btn btn-default">view</button>
            </form>

             </div> </div> </div></div>
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>