<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                           <div class="col-lg-12">
      <div class="panel panel-default">
     <div class="panel-heading">Student fee balance</div> 
        <div class="panel-body">
       <table class="table table-bordered">
      <thead>
      <tr>
          <td>Regno</td>
          <td></td>
          <td>Username</td>
          <td></td>
        </tr>
        <tr>
          <td>Email</td>
          <td></td>
          <td>Class</td>
          <td></td>
        </tr>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>amount</th>
          <th>Payments</th>
        </tr>
      </thead>
      <tbody>

       <tr>
          <td colspan="3">Balance brought forward</td>
          <td></td>
        </tr>
    <?php foreach($expenceflows as $x): ?>
        <tr>
          <td><?php echo e($x -> id); ?></td>
          <td><?php echo e($x -> expenceid); ?></td>
          <td><?php echo e($x -> amount); ?></td>
          <td></td>
        </tr>
       <?php endforeach; ?>
       <tr>
          <td colspan="2">Total</td>
          <td></td>
          <td></td>
        </tr>
       <tr>
          <td colspan="3">payments</td>
          <td></td>
        </tr>
       <tr>
          <td colspan="3">Balance</td>
          <td></td>
        </tr>
      </tbody>
    </table>
    </div></div></div> </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>