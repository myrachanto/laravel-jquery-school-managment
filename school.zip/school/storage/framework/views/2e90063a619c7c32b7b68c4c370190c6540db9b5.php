<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-12">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Results</h2> of <?php echo e($exam->name); ?></div> 
  <div class="panel-body"> <table class="table table-bordered">
      <thead>
        <tr>
          <th>studentid</th>
          <th>Regno</th>
          <th>username</th>
          <?php foreach($subject as $s): ?><th><?php echo e($s -> name); ?></th>
       <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>

    <?php foreach($answers as $x): ?>
        <tr>
          <td><?php echo e($x -> studentid); ?></td>
          <td><?php echo e($x -> regno); ?></td>
          <td><?php echo e($x -> username); ?></td>
          <?php foreach($subject->$answers as $t): ?>
          <td><?php echo e($t->subject); ?></td><td><?php echo e($t->result); ?></td>
       <?php endforeach; ?>          
        </tr>
       <?php endforeach; ?>
      </tbody>
    </table>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>