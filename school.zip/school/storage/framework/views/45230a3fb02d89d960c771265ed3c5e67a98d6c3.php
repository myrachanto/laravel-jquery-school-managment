<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-8">
      <div class="panel panel-default">
     <div class="panel-heading"><h2>Select class to view</h2></div> 
        <div class="panel-body">
                                <?php foreach($yos as $z): ?>
                        <a href="<?php echo e(url('/admin/yos/viewclass')); ?>/<?php echo e($z -> name); ?>">
                            <div class="panel-footer">
                                <span class="pull-left"><?php echo e($z -> name); ?></span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right">&#8594;</i></span>
                                <div class="clearfix"></div>
                            </div></a>
                   
                      <?php endforeach; ?>

             </div> </div> </div> 
             </div> </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>