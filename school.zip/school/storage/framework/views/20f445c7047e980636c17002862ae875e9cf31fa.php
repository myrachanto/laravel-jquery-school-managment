<?php $__env->startSection('content'); ?>
<div id="about" class="container-fluid carodiv2">
                            <div class="row">
                              <div class="col-lg-12">
      <div class="panel panel-default">
     <div class="panel-heading"><h2><?php echo e($subject->name); ?></h2><?php echo e($exam->name); ?> Class-<?php echo e($classes->name); ?>

     </div> 
        <div class="panel-body"> 
        <form action="<?php echo e(url('/admin/exam/Information')); ?>" method="post">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <table class="table table-bordered">
      <thead>
        <tr>
          <th>Name</th>
          <th>Regno</th>
          <th>Acedemic year</th>
          <th>Exam</th>
          <th><input type="checkbox" id="select_all" name="checked[]">Check All </th>
        </tr>
      </thead>
      <tbody>

    <?php foreach($student as $x): ?>
        <tr>
          <td><?php echo e($x -> username); ?></td>
          <td><?php echo e($x -> regno); ?></td>
          <td><?php echo e($x -> academicyear); ?></td>
          <td>          
            <input type="hidden" id="name" value="<?php echo e($x -> id); ?>" name="studentid[]">
          <input type="text" class="checkbox" id="score" name="score[]"></td>
          <td><input type="checkbox" id="checked" class="checkbox" name="checked[]"></td>
        </tr>
       <?php endforeach; ?>
      </tbody>
      <tr><td colspan="4" align="right">
               <input type="hidden" id="name" value="<?php echo e($subject -> id); ?>" name="subjectid">
               <input type="hidden" id="name" value="<?php echo e($exam -> id); ?>" name="examid">
               <input type="hidden" id="name" value="<?php echo e($classes -> id); ?>" name="classesid">

              <button type="submit" class="btn btn-default">Submit</button></td></tr></table>
    </table>               
            </form>
    <!-- add code ends -->
 
             </div> </div> </div> </div> </div>
<script type="text/javascript">
$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
});
</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>