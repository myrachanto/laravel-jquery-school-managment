<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="panel-body"> <table class="table table-bordered">
      <thead>
        <tr>
          <th>photo</th>
          <th>First Name</th>
          <th>Last name</th>
          <th>Email</th>
          <th>Phone number</th>
          <th>Take action</th>
        </tr>
      </thead>
      <tbody>

    <?php foreach($user as $x): ?>
        <tr>
           <td><img src="<?php echo e(asset($x->foto)); ?>" class="imgstyle" width="50" height="50" alt="<?php echo e($x->username); ?>" /></td>
          <td><?php echo e($x -> fname); ?></td>
          <td><?php echo e($x -> lname); ?></td>
          <td><?php echo e($x -> email); ?></td>
          <td><?php echo e($x -> primary_p_no); ?></td>
          <td><a href="<?php echo e(url('/admin/teacher/Apersona')); ?>/<?php echo e($x -> username); ?>">fire</a></td>
          
        </tr>
       <?php endforeach; ?>
      </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>