<?php $__env->startSection('header1'); ?>
    <meta name="description" content="Get the best responsive ecommerce website and web application for you business today designed with efficience and integrity" />
	<title>Best responsive ecommerce web application developers in english and espanol</title>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="panel-body"> <table class="table table-bordered">
      <thead>
        <tr>
          <th>Photo</th>
          <th>Name</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>

    <?php foreach($subject as $x): ?>
        <tr>
          <td><img src="<?php echo e(asset($x->foto)); ?>" class="imgstyle" width="50" height="50" alt="<?php echo e($x->username); ?>" /></td>
          <td><?php echo e($x -> name); ?></td>
          <td><?php echo e($x -> description); ?></td>
          
        </tr>
       <?php endforeach; ?>
      </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>